import 'dart:convert';

import 'package:dart_schema_builder/dart_schema_builder.dart' show ObjectSchema;

import '../../fcp_client.dart';

/// Extension to provide JSON stringification for map-based objects.
extension JsonEncodeMap on Map<String, Object?> {
  /// Converts this map object to a JSON string.
  ///
  /// - [indent]: If non-empty, the JSON output will be pretty-printed with
  ///   the given indent.
  String toJsonString({String indent = ''}) {
    if (indent.isNotEmpty) {
      return JsonEncoder.withIndent(indent).convert(this);
    }
    return const JsonEncoder().convert(this);
  }
}

extension type JsonObjectBase(Map<String, Object?> _json) {
  Map<String, Object?> toJson() => _json;
}

// -----------------------------------------------------------------------------
// Catalog-related Models
// -----------------------------------------------------------------------------

/// A type-safe wrapper for the `WidgetCatalog` JSON object.
///
/// The catalog is a client-defined document that specifies which widgets,
/// properties, events, and data structures the application is capable of
/// handling. It serves as a strict contract between the client and the server.
extension type WidgetCatalog.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory WidgetCatalog({
    String catalogVersion = fcpVersion,
    required Map<String, Object?> dataTypes,
    required Map<String, WidgetDefinition?> items,
  }) => WidgetCatalog.fromMap({
    'catalogVersion': catalogVersion,
    'dataTypes': dataTypes,
    'items': items,
  });
  String get catalogVersion => _json['catalogVersion'] as String;
  Map<String, Object?> get dataTypes =>
      _json['dataTypes'] as Map<String, Object?>;
  Map<String, WidgetDefinition?> get items =>
      (_json['items'] as Map).cast<String, WidgetDefinition?>();
}

/// A type-safe wrapper for a `WidgetDefinition` JSON object.
///
/// This object describes a single renderable widget type, including its
/// supported properties and the events it can emit.
extension type WidgetDefinition.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory WidgetDefinition({
    required ObjectSchema properties,
    ObjectSchema? events,
  }) => WidgetDefinition.fromMap({
    'properties': properties.value,
    if (events != null) 'events': events.value,
  });
  ObjectSchema get properties {
    final props = _json['properties'] as Map<String, Object?>?;
    if (props == null) {
      return ObjectSchema(properties: {});
    }
    return ObjectSchema.fromMap(props);
  }

  ObjectSchema? get events {
    final events = _json['events'] as Map<String, Object?>?;
    return events == null ? null : ObjectSchema.fromMap(events);
  }
}

// -----------------------------------------------------------------------------
// UI Packet & Layout Models
// -----------------------------------------------------------------------------

/// A type-safe wrapper for a `DynamicUIPacket` JSON object.
///
/// This is the atomic and self-contained description of a UI view at a
/// specific moment, containing the layout, state, and metadata.
extension type DynamicUIPacket.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory DynamicUIPacket({
    String formatVersion = fcpVersion,
    required Layout layout,
    required Map<String, Object?> state,
    Map<String, Object?>? metadata,
  }) => DynamicUIPacket.fromMap({
    'formatVersion': formatVersion,
    'layout': layout.toJson(),
    'state': state,
    if (metadata != null) 'metadata': metadata,
  });
  String get formatVersion => _json['formatVersion'] as String;
  Layout get layout =>
      Layout.fromMap(_json['layout'] as Map<String, Object?>? ?? {});
  Map<String, Object?> get state =>
      _json['state'] as Map<String, Object?>? ?? {};
  Map<String, Object?>? get metadata =>
      _json['metadata'] as Map<String, Object?>?;
}

/// A type-safe wrapper for a `Layout` JSON object.
///
/// The layout defines the UI structure using a flat adjacency list model,
/// where parent-child relationships are established through ID references.
extension type Layout.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory Layout({required String root, required List<LayoutNode> nodes}) =>
      Layout.fromMap({
        'root': root,
        'nodes': nodes.map((e) => e.toJson()).toList(),
      });
  String get root => _json['root'] as String;
  List<LayoutNode> get nodes {
    final nodeList = _json['nodes'] as List<Object?>? ?? [];
    return nodeList
        .cast<Map<String, Object?>>()
        .map(LayoutNode.fromMap)
        .toList();
  }
}

/// A type-safe wrapper for a `LayoutNode` JSON object.
///
/// A layout node represents a single widget instance in the layout,
/// including its type, properties, and data bindings.
extension type LayoutNode.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory LayoutNode({
    required String id,
    required String type,
    Map<String, Object?>? properties,
    Map<String, Binding>? bindings,
    LayoutNode? itemTemplate,
  }) => LayoutNode.fromMap({
    'id': id,
    'type': type,
    if (properties != null) 'properties': properties,
    if (bindings != null)
      'bindings': bindings.map((key, value) => MapEntry(key, value.toJson())),
    if (itemTemplate != null) 'itemTemplate': itemTemplate.toJson(),
  });

  String get id => _json['id'] as String;
  String get type => _json['type'] as String;
  Map<String, Object?>? get properties =>
      _json['properties'] as Map<String, Object?>?;
  Map<String, Binding>? get bindings {
    final bindingsMap = _json['bindings'] as Map<String, Object?>?;
    return bindingsMap?.map(
      (key, value) =>
          MapEntry(key, Binding.fromMap(value as Map<String, Object?>)),
    );
  }

  LayoutNode? get itemTemplate {
    final templateJson = _json['itemTemplate'] as Map<String, Object?>?;
    return templateJson != null ? LayoutNode.fromMap(templateJson) : null;
  }
}

// -----------------------------------------------------------------------------
// Event & Update Models
// -----------------------------------------------------------------------------

/// A type-safe wrapper for an `EventPayload` JSON object.
///
/// This payload is sent from the client to the server when a user interaction
/// occurs, such as a button press.
extension type EventPayload.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory EventPayload({
    required String sourceNodeId,
    required String eventName,
    Map<String, Object?>? arguments,
    DateTime? timestamp,
  }) => EventPayload.fromMap({
    'sourceNodeId': sourceNodeId,
    'eventName': eventName,
    'timestamp': (timestamp ?? DateTime.now()).toIso8601String(),
    if (arguments != null) 'arguments': arguments,
  });
  String get sourceNodeId => _json['sourceNodeId'] as String;
  String get eventName => _json['eventName'] as String;
  Map<String, Object?>? get arguments =>
      _json['arguments'] as Map<String, Object?>?;
  DateTime get timestamp => DateTime.parse(_json['timestamp'] as String);
}

/// A type-safe wrapper for a `StateUpdate` payload, which uses the JSON Patch
/// standard (RFC 6902) to deliver targeted data-only updates to the client.
extension type StateUpdate.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory StateUpdate({required List<Map<String, Object?>> patches}) =>
      StateUpdate.fromMap({'patches': patches});
  List<Map<String, Object?>> get patches => (_json['patches'] as List<Object?>)
      .cast<Map<String, Object?>>()
      .where((element) {
        return element.keys.isNotEmpty;
      })
      .toList();
}

/// A type-safe wrapper for a `LayoutUpdate` payload, which delivers surgical
/// modifications to the UI's structure (e.g., adding or removing catalog
/// items).
extension type LayoutUpdate.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory LayoutUpdate({required List<LayoutOperation> operations}) =>
      LayoutUpdate.fromMap({
        'operations': operations.map((e) => e.toJson()).toList(),
      });
  List<LayoutOperation> get operations {
    final opsList = _json['operations'] as List<Object?>;
    return opsList
        .cast<Map<String, Object?>>()
        .map(LayoutOperation.fromMap)
        .toList();
  }
}

/// A type-safe wrapper for a `LayoutOperation` JSON object, which represents
/// a single operation (add, remove, or replace) within a `LayoutUpdate`.
extension type LayoutOperation.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory LayoutOperation({
    required String op,
    List<LayoutNode>? nodes,
    List<String>? nodeIds,
    String? targetNodeId,
    String? targetProperty,
  }) => LayoutOperation.fromMap({
    'op': op,
    if (nodes != null) 'nodes': nodes.map((e) => e.toJson()).toList(),
    if (nodeIds != null) 'nodeIds': nodeIds,
    if (targetNodeId != null) 'targetNodeId': targetNodeId,
    if (targetProperty != null) 'targetProperty': targetProperty,
  });
  String get op => _json['op'] as String;

  // For 'add' and 'replace'
  List<LayoutNode>? get nodes {
    final nodeList = _json['nodes'] as List<Object?>?;
    return nodeList
        ?.cast<Map<String, Object?>>()
        .map(LayoutNode.fromMap)
        .toList();
  }

  // For 'remove'
  List<String>? get nodeIds {
    final idList = _json['nodeIds'] as List<Object?>?;
    return idList?.cast<String>();
  }

  // For 'add'
  String? get targetNodeId => _json['targetNodeId'] as String?;
  String? get targetProperty => _json['targetProperty'] as String?;
}

// -----------------------------------------------------------------------------
// State & Binding Models
// -----------------------------------------------------------------------------

/// A type-safe wrapper for a `Binding` JSON object.
///
/// A binding forges the connection between a widget property in the
/// layout and a value in the state object, with optional client-side
/// transformations.
extension type Binding.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory Binding({
    required String path,
    String? format,
    Condition? condition,
    MapTransformer? map,
  }) => Binding.fromMap({
    'path': path,
    if (format != null) 'format': format,
    if (condition != null) 'condition': condition.toJson(),
    if (map != null) 'map': map.toJson(),
  });

  String get path => _json['path'] as String;
  String? get format => _json['format'] as String?;
  Condition? get condition {
    final conditionJson = _json['condition'] as Map<String, Object?>?;
    return conditionJson != null ? Condition.fromMap(conditionJson) : null;
  }

  MapTransformer? get map {
    final mapJson = _json['map'] as Map<String, Object?>?;
    return mapJson != null ? MapTransformer.fromMap(mapJson) : null;
  }

  Map<String, Object?> toJson() => _json;
}

/// A type-safe wrapper for a `Condition` transformer JSON object.
///
/// This transformer evaluates a boolean value from the state and returns one
/// of two specified values.
extension type Condition.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory Condition({Object? ifValue, Object? elseValue}) => Condition.fromMap({
    if (ifValue != null) 'if': ifValue,
    if (elseValue != null) 'else': elseValue,
  });
  Object? get ifValue => _json['if'];
  Object? get elseValue => _json['else'];
}

/// A type-safe wrapper for a `Map` transformer JSON object.
///
/// This transformer maps a value from the state to another value, with an
/// optional fallback.
extension type MapTransformer.fromMap(Map<String, Object?> _json)
    implements JsonObjectBase {
  factory MapTransformer({
    required Map<String, Object?> mapping,
    Object? fallback,
  }) => MapTransformer.fromMap({
    'mapping': mapping,
    if (fallback != null) 'fallback': fallback,
  });
  Map<String, Object?> get mapping => _json['mapping'] as Map<String, Object?>;
  Object? get fallback => _json['fallback'];
}
