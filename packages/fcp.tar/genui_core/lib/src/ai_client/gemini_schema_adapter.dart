// Copyright 2025 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'package:dart_schema_builder/dart_schema_builder.dart' as dsb;
import 'package:firebase_ai/firebase_ai.dart' as firebase_ai;

/// An error that occurred during schema adaptation.
///
/// This class encapsulates information about an error that occurred while
/// converting a `dart_schema_builder` schema to a `firebase_ai` schema.
class GeminiSchemaAdapterError {
  /// Creates an [GeminiSchemaAdapterError].
  ///
  /// The [message] describes the error, and the [path] indicates where in the
  /// schema the error occurred.
  GeminiSchemaAdapterError(this.message, {required this.path});

  /// A message describing the error.
  final String message;

  /// The path to the location in the schema where the error occurred.
  final List<String> path;

  @override
  String toString() => 'Error at path "${path.join('/')}": $message';
}

/// The result of a schema adaptation.
///
/// This class holds the result of a schema conversion, including the adapted
/// schema and any errors that occurred during the process.
class GeminiSchemaAdapterResult {
  /// Creates an [GeminiSchemaAdapterResult].
  ///
  /// The [schema] is the result of the adaptation, and [errors] is a list of
  /// any errors that were encountered.
  GeminiSchemaAdapterResult(this.schema, this.errors);

  /// The adapted schema.
  ///
  /// This may be null if the schema could not be adapted at all.
  final firebase_ai.Schema? schema;

  /// A list of errors that occurred during adaptation.
  final List<GeminiSchemaAdapterError> errors;
}

/// An adapter to convert a [dsb.Schema] from the `dart_schema_builder` package
/// to a [firebase_ai.Schema] from the `firebase_ai` package.
///
/// This adapter attempts to convert as much of the schema as possible,
/// accumulating errors for any unsupported keywords or structures. The goal is
/// to produce a usable `firebase_ai` schema even if the source schema contains
/// features not supported by `firebase_ai`.
///
/// Unsupported keywords will be ignored, and an [GeminiSchemaAdapterError] will
/// be added to the [GeminiSchemaAdapterResult.errors] list for each ignored
/// keyword.
class GeminiSchemaAdapter {
  final List<GeminiSchemaAdapterError> _errors = [];

  /// Adapts the given [schema] from `dart_schema_builder` to `firebase_ai`
  /// format.
  ///
  /// This is the main entry point for the adapter. It takes a [dsb.Schema] and
  /// returns an [GeminiSchemaAdapterResult] containing the adapted
  /// [firebase_ai.Schema] and a list of any errors that occurred.
  GeminiSchemaAdapterResult adapt(dsb.Schema schema) {
    _errors.clear();
    final firebaseSchema = _adapt(schema, ['#']);
    return GeminiSchemaAdapterResult(
      firebaseSchema,
      List.unmodifiable(_errors),
    );
  }

  /// Recursively adapts a sub-schema.
  ///
  /// This method is called by [adapt] and recursively traverses the schema,
  /// converting each part to the `firebase_ai` format.
  firebase_ai.Schema? _adapt(dsb.Schema schema, List<String> path) {
    if (schema.value.isEmpty) {
      // An empty schema allows any value.
      return firebase_ai.Schema(firebase_ai.SchemaType.object);
    }
    if (schema.anyOf case final List<Object?> anyOf) {
      final schemas = <firebase_ai.Schema>[];
      for (final subSchema in anyOf) {
        if (subSchema is dsb.Schema) {
          final adapted = _adapt(subSchema, path);
          if (adapted != null) {
            schemas.add(adapted);
          }
        }
      }
      return firebase_ai.Schema.anyOf(schemas: schemas);
    }

    _checkUnsupportedGlobalKeywords(schema, path);

    final type = schema.type;
    String? typeName;
    if (type is String) {
      typeName = type;
    } else if (type is List) {
      if (type.isEmpty) {
        _errors.add(
          GeminiSchemaAdapterError(
            'Schema has an empty "type" array.',
            path: path,
          ),
        );
        return null;
      }
      typeName = type.first as String;
      if (type.length > 1) {
        _errors.add(
          GeminiSchemaAdapterError(
            'Multiple types found (${type.join(', ')}). Only the first type '
            '"$typeName" will be used.',
            path: path,
          ),
        );
      }
    } else if (dsb.ObjectSchema.fromMap(schema.value).properties != null ||
        schema.value.containsKey('properties')) {
      typeName = dsb.JsonType.object.typeName;
    } else if (schema.value.containsKey('items')) {
      typeName = dsb.JsonType.list.typeName;
    }

    if (typeName == null) {
      // This is likely a Schema.any() with some metadata. For Gemini, this
      // is interpreted as a generic object that can hold any value.
      final otherKeys = schema.value.keys.toSet().difference(const {
        'title',
        'description',
        '\$comment',
      });
      if (otherKeys.isEmpty) {
        final anyOfSchema = firebase_ai.Schema.anyOf(
          schemas: [
            firebase_ai.Schema(firebase_ai.SchemaType.string),
            firebase_ai.Schema(firebase_ai.SchemaType.number),
            firebase_ai.Schema(firebase_ai.SchemaType.integer),
            firebase_ai.Schema(firebase_ai.SchemaType.boolean),
            firebase_ai.Schema(firebase_ai.SchemaType.object),
            firebase_ai.Schema(
              firebase_ai.SchemaType.array,
              items: firebase_ai.Schema(firebase_ai.SchemaType.string),
            ),
            firebase_ai.Schema(
              firebase_ai.SchemaType.array,
              items: firebase_ai.Schema(firebase_ai.SchemaType.number),
            ),
            firebase_ai.Schema(
              firebase_ai.SchemaType.array,
              items: firebase_ai.Schema(firebase_ai.SchemaType.integer),
            ),
            firebase_ai.Schema(
              firebase_ai.SchemaType.array,
              items: firebase_ai.Schema(firebase_ai.SchemaType.boolean),
            ),
            firebase_ai.Schema(
              firebase_ai.SchemaType.array,
              items: firebase_ai.Schema(firebase_ai.SchemaType.object),
            ),
            firebase_ai.Schema(firebase_ai.SchemaType.object, nullable: true),
          ],
        );
        if (schema.description case final String description) {
          return firebase_ai.Schema(
            anyOfSchema.type,
            anyOf: anyOfSchema.anyOf,
            description: description,
          );
        }
        return anyOfSchema;
      }
    }

    if (typeName == null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Schema must have a "type" or be implicitly typed with "properties" '
          'or "items".',
          path: path,
        ),
      );
      return null;
    }

    firebase_ai.Schema? baseSchema;
    switch (typeName) {
      case 'object':
        baseSchema = _adaptObject(schema, path);
        break;
      case 'array':
        baseSchema = _adaptArray(schema, path);
        break;
      case 'string':
        baseSchema = _adaptString(schema, path);
        break;
      case 'number':
        baseSchema = _adaptNumber(schema, path);
        break;
      case 'integer':
        baseSchema = _adaptInteger(schema, path);
        break;
      case 'boolean':
        baseSchema = _adaptBoolean(schema, path);
        break;
      case 'null':
        baseSchema = _adaptNull(schema, path);
        break;
      default:
        _errors.add(
          GeminiSchemaAdapterError(
            'Unsupported schema type "$typeName".',
            path: path,
          ),
        );
        return null;
    }

    if (baseSchema != null && schema.description != null) {
      // Create a new schema with the description.
      return firebase_ai.Schema(
        baseSchema.type,
        description: schema.description,
        format: baseSchema.format,
        properties: baseSchema.properties,
        optionalProperties: baseSchema.optionalProperties,
        items: baseSchema.items,
        minItems: baseSchema.minItems,
        maxItems: baseSchema.maxItems,
        minimum: baseSchema.minimum,
        maximum: baseSchema.maximum,
        enumValues: baseSchema.enumValues,
        nullable: baseSchema.nullable,
        anyOf: baseSchema.anyOf,
      );
    }

    return baseSchema;
  }

  /// Checks for and logs errors for unsupported global keywords.
  void _checkUnsupportedGlobalKeywords(dsb.Schema schema, List<String> path) {
    const unsupportedKeywords = {
      '\$comment',
      'default',
      'examples',
      'deprecated',
      'readOnly',
      'writeOnly',
      '\$defs',
      '\$ref',
      '\$anchor',
      '\$dynamicAnchor',
      '\$id',
      '\$schema',
      'allOf',
      'oneOf',
      'not',
      'if',
      'then',
      'else',
      'dependentSchemas',
      'const',
    };

    for (final keyword in unsupportedKeywords) {
      if (schema.value.containsKey(keyword)) {
        _errors.add(
          GeminiSchemaAdapterError(
            'Unsupported keyword "$keyword". It will be ignored.',
            path: path,
          ),
        );
      }
    }
  }

  /// Adapts an object schema.
  firebase_ai.Schema? _adaptObject(dsb.Schema dsbSchema, List<String> path) {
    final objectSchema = dsb.ObjectSchema.fromMap(dsbSchema.value);

    // A "true" boolean schema has an empty value.
    if (objectSchema.additionalProperties?.value.isEmpty ?? false) {
      // If additionalProperties is true, we create a generic object schema
      // that allows any properties.
      return firebase_ai.Schema(firebase_ai.SchemaType.object);
    }

    Map<String, firebase_ai.Schema>? properties;
    if (objectSchema.properties != null) {
      properties = {};
      for (final entry in objectSchema.properties!.entries) {
        final propertyPath = [...path, 'properties', entry.key];
        final adaptedProperty = _adapt(entry.value, propertyPath);
        if (adaptedProperty != null) {
          properties[entry.key] = adaptedProperty;
        }
      }
    }

    if (objectSchema.patternProperties != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "patternProperties". It will be ignored.',
          path: path,
        ),
      );
    }
    if (objectSchema.dependentRequired != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "dependentRequired". It will be ignored.',
          path: path,
        ),
      );
    }
    if (objectSchema.additionalProperties != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "additionalProperties". It will be ignored.',
          path: path,
        ),
      );
    }
    if (objectSchema.unevaluatedProperties != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "unevaluatedProperties". It will be ignored.',
          path: path,
        ),
      );
    }
    if (objectSchema.propertyNames != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "propertyNames". It will be ignored.',
          path: path,
        ),
      );
    }
    if (objectSchema.minProperties != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "minProperties". It will be ignored.',
          path: path,
        ),
      );
    }
    if (objectSchema.maxProperties != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "maxProperties". It will be ignored.',
          path: path,
        ),
      );
    }

    final allProperties = properties?.keys.toSet() ?? {};
    final requiredProperties = objectSchema.required?.toSet() ?? {};
    final optionalProperties = allProperties
        .difference(requiredProperties)
        .toList();

    return firebase_ai.Schema(
      firebase_ai.SchemaType.object,
      properties: properties,
      optionalProperties: optionalProperties,
    );
  }

  /// Adapts an array schema.
  firebase_ai.Schema? _adaptArray(dsb.Schema dsbSchema, List<String> path) {
    final listSchema = dsb.ListSchema.fromMap(dsbSchema.value);

    if (listSchema.items == null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Array schema must have an "items" property.',
          path: path,
        ),
      );
      return null;
    }

    final itemsPath = [...path, 'items'];
    final adaptedItems = _adapt(listSchema.items!, itemsPath);
    if (adaptedItems == null) {
      return null;
    }

    if (listSchema.prefixItems != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "prefixItems". It will be ignored.',
          path: path,
        ),
      );
    }
    if (listSchema.unevaluatedItems != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "unevaluatedItems". It will be ignored.',
          path: path,
        ),
      );
    }
    if (listSchema.contains != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "contains". It will be ignored.',
          path: path,
        ),
      );
    }
    if (listSchema.minContains != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "minContains". It will be ignored.',
          path: path,
        ),
      );
    }
    if (listSchema.maxContains != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "maxContains". It will be ignored.',
          path: path,
        ),
      );
    }
    if (listSchema.uniqueItems ?? false) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "uniqueItems". It will be ignored.',
          path: path,
        ),
      );
    }

    return firebase_ai.Schema(
      firebase_ai.SchemaType.array,
      items: adaptedItems,
      minItems: listSchema.minItems,
      maxItems: listSchema.maxItems,
    );
  }

  /// Adapts a string schema.
  firebase_ai.Schema? _adaptString(dsb.Schema dsbSchema, List<String> path) {
    final stringSchema = dsb.StringSchema.fromMap(dsbSchema.value);
    if (stringSchema.minLength != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "minLength". It will be ignored.',
          path: path,
        ),
      );
    }
    if (stringSchema.maxLength != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "maxLength". It will be ignored.',
          path: path,
        ),
      );
    }
    if (stringSchema.pattern != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "pattern". It will be ignored.',
          path: path,
        ),
      );
    }
    return firebase_ai.Schema(
      firebase_ai.SchemaType.string,
      format: stringSchema.format,
      enumValues: stringSchema.enumValues?.map((e) => e.toString()).toList(),
    );
  }

  /// Adapts a number schema.
  firebase_ai.Schema? _adaptNumber(dsb.Schema dsbSchema, List<String> path) {
    final numberSchema = dsb.NumberSchema.fromMap(dsbSchema.value);
    if (numberSchema.exclusiveMinimum != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "exclusiveMinimum". It will be ignored.',
          path: path,
        ),
      );
    }
    if (numberSchema.exclusiveMaximum != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "exclusiveMaximum". It will be ignored.',
          path: path,
        ),
      );
    }
    if (numberSchema.multipleOf != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "multipleOf". It will be ignored.',
          path: path,
        ),
      );
    }
    return firebase_ai.Schema(
      firebase_ai.SchemaType.number,
      minimum: numberSchema.minimum?.toDouble(),
      maximum: numberSchema.maximum?.toDouble(),
    );
  }

  /// Adapts an integer schema.
  firebase_ai.Schema? _adaptInteger(dsb.Schema dsbSchema, List<String> path) {
    final integerSchema = dsb.IntegerSchema.fromMap(dsbSchema.value);
    if (integerSchema.exclusiveMinimum != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "exclusiveMinimum". It will be ignored.',
          path: path,
        ),
      );
    }
    if (integerSchema.exclusiveMaximum != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "exclusiveMaximum". It will be ignored.',
          path: path,
        ),
      );
    }
    if (integerSchema.multipleOf != null) {
      _errors.add(
        GeminiSchemaAdapterError(
          'Unsupported keyword "multipleOf". It will be ignored.',
          path: path,
        ),
      );
    }
    return firebase_ai.Schema(
      firebase_ai.SchemaType.integer,
      minimum: integerSchema.minimum?.toDouble(),
      maximum: integerSchema.maximum?.toDouble(),
    );
  }

  /// Adapts a boolean schema.
  firebase_ai.Schema? _adaptBoolean(dsb.Schema dsbSchema, List<String> path) {
    return firebase_ai.Schema(firebase_ai.SchemaType.boolean);
  }

  /// Adapts a null schema.
  firebase_ai.Schema? _adaptNull(dsb.Schema dsbSchema, List<String> path) {
    return firebase_ai.Schema(firebase_ai.SchemaType.object, nullable: true);
  }
}
