# genui_core

A UI-agnostic, pure Dart package responsible for conversation management, AI interaction (`AiClient`), and business logic.

This package is part of the GenUI project. It is not intended for general use.