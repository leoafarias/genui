// Copyright 2025 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'package:dart_schema_builder/dart_schema_builder.dart' as dsb;
import 'package:firebase_ai/firebase_ai.dart' as firebase_ai;
import 'package:genui_core/src/ai_client/gemini_schema_adapter.dart';
import 'package:test/test.dart';

void main() {
  group('SchemaAdapter', () {
    late GeminiSchemaAdapter adapter;

    setUp(() {
      adapter = GeminiSchemaAdapter();
    });

    group('adaptObject', () {
      test('should adapt a simple object schema', () {
        final dsbSchema = dsb.S.object(
          properties: {'name': dsb.S.string(), 'age': dsb.S.integer()},
          required: ['name'],
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.object);
        expect(result.schema!.properties, hasLength(2));
        expect(
          result.schema!.properties!['name']!.type,
          firebase_ai.SchemaType.string,
        );
        expect(
          result.schema!.properties!['age']!.type,
          firebase_ai.SchemaType.integer,
        );
        expect(result.schema!.optionalProperties, equals(['age']));
      });

      test('should handle unsupported keywords and log errors', () {
        final dsbSchema = dsb.S.object(
          properties: {'name': dsb.S.string()},
          minProperties: 1,
          maxProperties: 5,
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, hasLength(2));
        expect(
          result.errors[0].message,
          contains('Unsupported keyword "minProperties"'),
        );
        expect(
          result.errors[1].message,
          contains('Unsupported keyword "maxProperties"'),
        );
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.object);
      });

      test('should copy the description for an object', () {
        final dsbSchema = dsb.S.object(
          description: 'A test object.',
          properties: {'name': dsb.S.string()},
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.description, 'A test object.');
      });

      test('should handle an object with additionalProperties', () {
        final dsbSchema = dsb.S.object(
          description: 'An object with additional properties.',
          additionalProperties: true,
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.object);
        expect(result.schema!.properties, isNull);
        expect(result.schema!.optionalProperties, isNull);
        expect(
          result.schema!.description,
          'An object with additional properties.',
        );
      });
    });

    group('adaptArray', () {
      test('should adapt a simple array schema', () {
        final dsbSchema = dsb.S.list(
          items: dsb.S.string(),
          minItems: 1,
          maxItems: 10,
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.array);
        expect(result.schema!.items, isNotNull);
        expect(result.schema!.items!.type, firebase_ai.SchemaType.string);
        expect(result.schema!.minItems, 1);
        expect(result.schema!.maxItems, 10);
      });

      test('should copy the description for an array', () {
        final dsbSchema = dsb.S.list(
          description: 'A test array.',
          items: dsb.S.string(),
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.description, 'A test array.');
      });

      test('should log an error if items is missing', () {
        final dsbSchema = dsb.Schema.fromMap({'type': 'array'});
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isNotEmpty);
        expect(
          result.errors.first.message,
          'Array schema must have an "items" property.',
        );
        expect(result.schema, isNull);
      });

      test('should handle unsupported keywords and log errors', () {
        final dsbSchema = dsb.S.list(items: dsb.S.string(), uniqueItems: true);

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, hasLength(1));
        expect(
          result.errors[0].message,
          contains('Unsupported keyword "uniqueItems"'),
        );
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.array);
      });
    });

    group('adaptString', () {
      test('should adapt a simple string schema', () {
        final dsbSchema = dsb.S.string(
          format: 'email',
          enumValues: ['test@example.com', 'user@example.com'],
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.string);
        expect(result.schema!.format, 'email');
        expect(result.schema!.enumValues, [
          'test@example.com',
          'user@example.com',
        ]);
      });

      test('should copy the description for a string', () {
        final dsbSchema = dsb.S.string(description: 'A test string.');

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.description, 'A test string.');
      });

      test('should handle unsupported keywords and log errors', () {
        final dsbSchema = dsb.S.string(
          minLength: 1,
          maxLength: 10,
          pattern: r'^[a-zA-Z]+$',
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, hasLength(3));
        expect(
          result.errors[0].message,
          contains('Unsupported keyword "minLength"'),
        );
        expect(
          result.errors[1].message,
          contains('Unsupported keyword "maxLength"'),
        );
        expect(
          result.errors[2].message,
          contains('Unsupported keyword "pattern"'),
        );
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.string);
      });
    });

    group('adaptNumber', () {
      test('should adapt a simple number schema', () {
        final dsbSchema = dsb.S.number(minimum: 0.0, maximum: 100.0);

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.number);
        expect(result.schema!.minimum, 0.0);
        expect(result.schema!.maximum, 100.0);
      });

      test('should copy the description for a number', () {
        final dsbSchema = dsb.S.number(description: 'A test number.');

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.description, 'A test number.');
      });

      test('should handle unsupported keywords and log errors', () {
        final dsbSchema = dsb.S.number(
          exclusiveMinimum: 0.0,
          exclusiveMaximum: 100.0,
          multipleOf: 5.0,
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, hasLength(3));
        expect(
          result.errors[0].message,
          contains('Unsupported keyword "exclusiveMinimum"'),
        );
        expect(
          result.errors[1].message,
          contains('Unsupported keyword "exclusiveMaximum"'),
        );
        expect(
          result.errors[2].message,
          contains('Unsupported keyword "multipleOf"'),
        );
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.number);
      });
    });

    group('adaptInteger', () {
      test('should adapt a simple integer schema', () {
        final dsbSchema = dsb.S.integer(minimum: 0, maximum: 100);

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.integer);
        expect(result.schema!.minimum, 0.0);
        expect(result.schema!.maximum, 100.0);
      });

      test('should copy the description for an integer', () {
        final dsbSchema = dsb.S.integer(description: 'A test integer.');

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.description, 'A test integer.');
      });

      test('should handle unsupported keywords and log errors', () {
        final dsbSchema = dsb.S.integer(
          exclusiveMinimum: 0,
          exclusiveMaximum: 100,
          multipleOf: 5,
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, hasLength(3));
        expect(
          result.errors[0].message,
          contains('Unsupported keyword "exclusiveMinimum"'),
        );
        expect(
          result.errors[1].message,
          contains('Unsupported keyword "exclusiveMaximum"'),
        );
        expect(
          result.errors[2].message,
          contains('Unsupported keyword "multipleOf"'),
        );
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.integer);
      });
    });

    group('adaptBoolean', () {
      test('should adapt a boolean schema', () {
        final dsbSchema = dsb.S.boolean();
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.boolean);
      });

      test('should copy the description for a boolean', () {
        final dsbSchema = dsb.S.boolean(description: 'A test boolean.');

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.description, 'A test boolean.');
      });
    });

    group('adaptNull', () {
      test('should adapt a null schema to a nullable object', () {
        final dsbSchema = dsb.S.nil();
        final result = adapter.adapt(dsbSchema);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.object);
        expect(result.schema!.nullable, isTrue);
      });

      test('should copy the description for a null', () {
        final dsbSchema = dsb.S.nil(description: 'A test null.');

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.description, 'A test null.');
      });
    });

    group('General Error Handling', () {
      test('should log an error for an unknown type', () {
        final dsbSchema = dsb.Schema.fromMap({'type': 'unknown'});
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isNotEmpty);
        expect(
          result.errors.first.message,
          'Unsupported schema type "unknown".',
        );
        expect(result.schema, isNull);
      });

      test('should adapt an empty schema to an object schema', () {
        final dsbSchema = dsb.Schema.fromMap({});
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.object);
      });

      test('should handle multiple types and use the first one', () {
        final dsbSchema = dsb.Schema.fromMap({
          'type': ['string', 'integer'],
        });
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, hasLength(1));
        expect(
          result.errors.first.message,
          'Multiple types found (string, integer). Only the first type '
          '"string" will be used.',
        );
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.string);
      });

      test('should handle an empty type array', () {
        final dsbSchema = dsb.Schema.fromMap({'type': []});
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, hasLength(1));
        expect(
          result.errors.first.message,
          'Schema has an empty "type" array.',
        );
        expect(result.schema, isNull);
      });
    });

    group('Edge Cases', () {
      test('should handle nested objects and arrays', () {
        final dsbSchema = dsb.S.object(
          properties: {
            'user': dsb.S.object(
              properties: {
                'name': dsb.S.string(),
                'roles': dsb.S.list(items: dsb.S.string()),
              },
              required: ['name'],
            ),
          },
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        final userSchema = result.schema!.properties!['user']!;
        expect(userSchema.type, firebase_ai.SchemaType.object);
        expect(userSchema.properties, hasLength(2));
        expect(userSchema.optionalProperties, equals(['roles']));
        final rolesSchema = userSchema.properties!['roles']!;
        expect(rolesSchema.type, firebase_ai.SchemaType.array);
        expect(rolesSchema.items!.type, firebase_ai.SchemaType.string);
      });

      test('should handle implicitly typed object schema', () {
        final dsbSchema = dsb.Schema.fromMap({
          'properties': {
            'name': {'type': 'string'},
          },
        });
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.object);
      });

      test('should handle implicitly typed array schema', () {
        final dsbSchema = dsb.Schema.fromMap({
          'items': {'type': 'string'},
        });
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.array);
      });

      test('should handle an empty object schema', () {
        final dsbSchema = dsb.S.object(properties: {});
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.object);
        expect(result.schema!.properties, isEmpty);
        expect(result.schema!.optionalProperties, isEmpty);
      });

      test('should handle an object with all properties required', () {
        final dsbSchema = dsb.S.object(
          properties: {'name': dsb.S.string(), 'age': dsb.S.integer()},
          required: ['name', 'age'],
        );
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.optionalProperties, isEmpty);
      });

      test('should handle an object with no required properties', () {
        final dsbSchema = dsb.S.object(
          properties: {'name': dsb.S.string(), 'age': dsb.S.integer()},
        );
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(
          result.schema!.optionalProperties,
          unorderedEquals(['name', 'age']),
        );
      });

      test('should handle an array of objects', () {
        final dsbSchema = dsb.S.list(
          items: dsb.S.object(
            properties: {'name': dsb.S.string(), 'value': dsb.S.integer()},
            required: ['name'],
          ),
        );
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.type, firebase_ai.SchemaType.array);
        final itemsSchema = result.schema!.items!;
        expect(itemsSchema.type, firebase_ai.SchemaType.object);
        expect(itemsSchema.properties, hasLength(2));
        expect(itemsSchema.optionalProperties, equals(['value']));
      });

      test('should handle "any" schema', () {
        final dsbSchema = dsb.S.any(description: 'Any value.');
        final result = adapter.adapt(dsbSchema);
        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.description, 'Any value.');
        final anyOf = result.schema!.anyOf;
        expect(anyOf, isNotNull);
        anyOf!;
        expect(anyOf, hasLength(11));
        expect(anyOf.where((s) => s.type == firebase_ai.SchemaType.string), isNotEmpty);
        expect(anyOf.where((s) => s.type == firebase_ai.SchemaType.number), isNotEmpty);
        expect(anyOf.where((s) => s.type == firebase_ai.SchemaType.integer), isNotEmpty);
        expect(anyOf.where((s) => s.type == firebase_ai.SchemaType.boolean), isNotEmpty);
        expect(anyOf.where((s) => s.type == firebase_ai.SchemaType.object && s.nullable != true), isNotEmpty);
        expect(anyOf.where((s) => s.type == firebase_ai.SchemaType.object && s.nullable == true), isNotEmpty);
        final arrays = anyOf.where((s) => s.type == firebase_ai.SchemaType.array).toList();
        expect(arrays, hasLength(5));
        expect(arrays.where((s) => s.items?.type == firebase_ai.SchemaType.string), isNotEmpty);
        expect(arrays.where((s) => s.items?.type == firebase_ai.SchemaType.number), isNotEmpty);
        expect(arrays.where((s) => s.items?.type == firebase_ai.SchemaType.integer), isNotEmpty);
        expect(arrays.where((s) => s.items?.type == firebase_ai.SchemaType.boolean), isNotEmpty);
        expect(arrays.where((s) => s.items?.type == firebase_ai.SchemaType.object), isNotEmpty);
      });
    });

    group('anyOf', () {
      test('should adapt a schema with anyOf', () {
        final dsbSchema = dsb.S.combined(
          anyOf: [dsb.S.string(), dsb.S.integer(), dsb.S.boolean()],
        );

        final result = adapter.adapt(dsbSchema);

        expect(result.errors, isEmpty);
        expect(result.schema, isNotNull);
        expect(result.schema!.anyOf, hasLength(3));
        expect(result.schema!.anyOf![0].type, firebase_ai.SchemaType.string);
        expect(result.schema!.anyOf![1].type, firebase_ai.SchemaType.integer);
        expect(result.schema!.anyOf![2].type, firebase_ai.SchemaType.boolean);
      });
    });
  });
}
