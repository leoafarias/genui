package com.example.genui_core

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
